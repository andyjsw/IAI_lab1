from source import display as ds
from source import read_maze
import time
# from importlib import reload
# reload(display)

BLACK = (0, 0, 0)
WHITE = (200, 200, 200)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (200, 200, 200)
YELLOW = (255, 255, 0)
GREY = (192,192,192)
GREY_YELLOW = (178, 156, 76)
VIOLET = (138,43,226)


def main(maze, n_rows, n_cols, start, end):
    ds.N_COLS = n_cols
    ds.N_ROWS = n_rows

    ds.main("BFS")

    ds.pygame.display.update()

    ds.draw(maze, n_rows, n_cols)

    bfs(maze, n_rows, n_cols, start, end)

    ds._exit()


def bfs(maze, n_rows, n_cols, start, end):
    blockSize = 20
    q = []
    q.append(maze[start.y][start.x])
    path = []
    while len(q) != 0:
        cur_pos = q.pop(0)
        cur_pos.visited = True

        for next in cur_pos.adjacent:
            x = next[0]
            y = next[1]
            if maze[y][x].valid == False:
                continue

            if maze[y][x].visited == False :
                maze[y][x].visited = True
                maze[y][x].prev = [cur_pos.y, cur_pos.x]
                q.append(maze[y][x])

            if (maze[y][x] != start):
                rect = ds.pygame.Rect(x*blockSize, y*blockSize, blockSize, blockSize)
                ds.SCREEN.fill(YELLOW, rect) 
                ds.pygame.display.update()
            time.sleep(0.01)    
            
            if maze[y][x] == end:
                path.append([y,x])
                maze[y][x].is_path = True
                while maze[path[-1][0]][path[-1][1]].prev is not None:
                    path.append(maze[path[-1][0]][path[-1][1]].prev)
                    maze[path[-1][0]][path[-1][1]].is_path = True
                path.reverse()     
    
    for p in path:
        rect = ds.pygame.Rect(p[1]*blockSize, p[0]*blockSize, blockSize, blockSize)
        ds.SCREEN.fill(BLUE, rect) 
        ds.pygame.display.update()
        time.sleep(0.1)
        
if __name__ == "__main__":
    main()