from operator import ne
from source import display as ds
from source import read_maze
import time
from queue import PriorityQueue


BLACK = (0, 0, 0)
WHITE = (200, 200, 200)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (200, 200, 200)
YELLOW = (255, 255, 0)
GREY = (192,192,192)
GREY_YELLOW = (178, 156, 76)
VIOLET = (138,43,226)


def main(maze, n_rows, n_cols, start, end):
	ds.N_COLS = n_cols
	ds.N_ROWS = n_rows

	ds.main("UCS")
	
	ds.pygame.display.update()

	ds.draw(maze, n_rows, n_cols)

	UCS(maze, n_rows, n_cols, start, end)
	
	ds._exit()


def heuristic(p1, p2):
	return ((p1[0]-p2[0])**2+(p1[1]-p2[1])**2)**0.5

def heuristic2(p1, p2):
	return (p1[0]-p2[0]) + (p1[1]-p2[1])


def UCS(maze, n_rows, n_cols, start, end):
	count = 0
	open_set = PriorityQueue()
	open_set.put((0, count, start))
	# came_from = {}
	# came_from[start] = start
	maze[start[1]][start[0]].prev = start
	inf = 1000000007
	g_score = {(x, y): inf for x in range(n_cols) for y in range(n_rows)}
	g_score[start] = 0

	open_set_hash = {start}

	blockSize = 20

	while not open_set.empty():
		for event in ds.pygame.event.get():
			if event.type == ds.pygame.QUIT:
				ds.pygame.quit()
				ds.sys.exit(0)

		current = open_set.get()[2]
		open_set_hash.remove(current)
		# print(current)

		if current == end:
			reconstruct_path(maze, end)
			read_maze.printMaze(maze, n_rows, n_cols)
			return True

		x = current[0]
		y = current[1]
		maze[y][x].visited = True
		if maze[y][x].valid == False:
			continue

		if (x != start[0] or y != start[1]):
			rect = ds.pygame.Rect(x*blockSize, y*blockSize, blockSize, blockSize)
			ds.SCREEN.fill(YELLOW, rect) 
			ds.pygame.display.update()
		time.sleep(0.05)

		for neighbor in maze[y][x].adjacent:
			if maze[neighbor[1]][neighbor[0]].visited == True:
				continue
			temp_g_score = g_score[current] + 1

			if temp_g_score < g_score[(neighbor[0], neighbor[1])]:
				# came_from[neighbor] = current
				maze[neighbor[1]][neighbor[0]].prev = current
				g_score[(neighbor[0], neighbor[1])] = temp_g_score
				if (neighbor[0], neighbor[1]) not in open_set_hash:
					count += 1
					open_set.put((g_score[(neighbor[0], neighbor[1])], count, (neighbor[0], neighbor[1])))
					open_set_hash.add((neighbor[0], neighbor[1]))

	return False


def reconstruct_path(maze, current):
	x = current[0]
	y = current[1]
	blockSize = 20 
	while current != maze[y][x].prev:
		rect = ds.pygame.Rect(x*blockSize, y*blockSize, blockSize, blockSize)
		ds.SCREEN.fill(BLUE, rect) 
		ds.pygame.display.update()
		time.sleep(0.05)
		maze[y][x].is_path = True
		# print(x, y, end=" ")
		px, py = maze[y][x].prev
		maze[py][px].next_on_path = (x, y)
		x, y = px, py
		current = (x, y)
