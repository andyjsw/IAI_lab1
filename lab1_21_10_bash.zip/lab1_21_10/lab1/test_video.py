import pygame

# Window size
WINDOW_WIDTH  = 400
WINDOW_HEIGHT = 400
WINDOW_FPS    = 30

### initialisation
pygame.init()
window = pygame.display.set_mode( ( WINDOW_WIDTH, WINDOW_HEIGHT ) )

frame_count = 0
exiting     = False
clock       = pygame.time.Clock()
while not exiting:
    # handle events
    # paint the screen

    # save the frame
    frame_count += 1
    filename = "screens/screen_%04d.png" % ( frame_count )
    pygame.image.save( window, filename )

    clock.tick( WINDOW_FPS )  # limit FPS