from source import astar
from source import read_maze
from importlib import reload
reload(astar)
reload(astar.ds)
reload(astar.read_maze)
import os.path

mazename = 'maze3'
al = "A star"

f = os.path.dirname("main.ipynb") + f'maze/{mazename}.txt'

data = read_maze.readMaze(str(f))
maze, n_rows, n_cols, start, end, bonus_list = data
start = (start.x, start.y)
end = (end.x, end.y)
# read_maze.printMaze(maze, n_rows, n_cols)
astar.main(maze, n_rows, n_cols, start, end)

import os
import subprocess

os.chdir('screens/')
# subprocess.call(['ffmpeg', '-i', 'picture%d0.png', 'output.avi'])
# subprocess.call(['ffmpeg', '-i', 'output.avi', '-t', '5', 'out.gif'])

subprocess.call(['ffmpeg', '-r', '15', '-f', 'image2', '-s', '400x400', '-i', 'screen_%04d.png', '-vcodec', 'libx264', '-crf', '25',  'window_video.mp4'])

import shutil
os.chdir('..')
# print(os.path())
# os.rename("screens/window_video.mp4", f"output/{mazename}/{al}/window_video.mp4")
# os.replace("screens/window_video.mp4", f"output/{mazename}/{al}/window_video.mp4")
shutil.move("screens/window_video.mp4", f"output/{mazename}/{al}/window_video.mp4")