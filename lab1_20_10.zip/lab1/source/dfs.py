from source import display as ds
from source import read_maze
import time
# from importlib import reload
# reload(display)

BLACK = (0, 0, 0)
WHITE = (200, 200, 200)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (200, 200, 200)
YELLOW = (255, 255, 0)
GREY = (192,192,192)
GREY_YELLOW = (178, 156, 76)
VIOLET = (138,43,226)


def main(maze, n_rows, n_cols, start, end):
    ds.N_COLS = n_cols
    ds.N_ROWS = n_rows

    ds.main("DFS")

    ds.pygame.display.update()

    ds.draw(maze, n_rows, n_cols)

    dfs(maze, n_rows, n_cols, start, end)

    ds._exit()


def dfs(maze, n_rows, n_cols, start, end):
    maze[start.y][start.x].prev = (start.x, start.y)
    # maze[start.y][start.x].visited = True
    blockSize = 20 
    st = []
    st.append((maze[start.y][start.x].x, maze[start.y][start.x].y))
    x = int
    y = int
    while len(st) != 0:
        for event in ds.pygame.event.get():
            if event.type == ds.pygame.QUIT:
                ds.pygame.quit()
                ds.sys.exit(0)
        cur_pos = st.pop()
        x = cur_pos[0]
        y = cur_pos[1]
        if maze[y][x].valid == False:
            continue

        if (maze[y][x].visited):
            continue
        maze[y][x].visited = True
        if (maze[y][x] != start):
            rect = ds.pygame.Rect(x*blockSize, y*blockSize, blockSize, blockSize)
            ds.SCREEN.fill(YELLOW, rect) 
            ds.pygame.display.update()
        time.sleep(0.05)

        if (maze[y][x] == end):
            break

        for next in maze[y][x].adjacent:
            if maze[next[1]][next[0]].visited == False:
                st.append((next[0], next[1]))
                # maze[next[1]][next[0]].visited = True
                maze[next[1]][next[0]].prev = (x, y)
                # if maze[y][x].is_teleport:
                #     print(x, y, maze[y][x].prev)

    while (x != maze[y][x].prev[0] or y != maze[y][x].prev[1]):
        rect = ds.pygame.Rect(x*blockSize, y*blockSize, blockSize, blockSize)
        ds.SCREEN.fill(BLUE, rect) 
        ds.pygame.display.update()
        time.sleep(0.05)
        maze[y][x].is_path = True
        # print(x, y, end=" ")
        x, y = maze[y][x].prev

    read_maze.printMaze(maze, n_rows, n_cols)


if __name__ == "__main__":
    main()