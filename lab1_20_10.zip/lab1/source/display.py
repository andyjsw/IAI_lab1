import pygame
import sys
import win32gui
import win32con
BLACK = (0, 0, 0)
WHITE = (200, 200, 200)
BLACK = (0, 0, 0)
RED = (255, 0, 0)
GREEN = (0, 255, 0)
BLUE = (0, 0, 255)
GRAY = (200, 200, 200)
YELLOW = (255, 255, 0)
GREY = (192,192,192)
GREY_YELLOW = (178, 156, 76)
VIOLET = (138,43,226)

WINDOW_HEIGHT = 400
WINDOW_WIDTH = 400
N_COLS = 10
N_ROWS = 10

def _exit():
    while True:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                # ds.sys.exit(0)
                return
            elif event.type == pygame.ACTIVEEVENT:
                a = 1


def main(al_name):
    global SCREEN, CLOCK, WINDOW_HEIGHT, WINDOW_WIDTH, N_COLS, N_ROWS
    pygame.init()
    pygame.display.set_caption(al_name)
    WINDOW_HEIGHT = N_ROWS*20
    WINDOW_WIDTH = N_COLS*20
    SCREEN = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))

    hwnd = win32gui.GetForegroundWindow()
    win32gui.ShowWindow(hwnd, win32con.SW_SHOWNOACTIVATE)
    win32gui.BringWindowToTop(hwnd)

    CLOCK = pygame.time.Clock()
    SCREEN.fill(WHITE)
    
    # hwnd = win32gui.GetForegroundWindow()

    # win32gui.SetWindowPos(hwnd, win32con.HWND_TOPMOST, 600, 300, 0, 0, win32con.SWP_NOSIZE)

    # while True:
    #     # drawGrid()
    #     for event in pygame.event.get():
    #         if event.type == pygame.QUIT:
    #             pygame.quit()
    #             sys.exit()

    #     pygame.display.update()


def drawGrid():
    blockSize = 20 #Set the size of the grid block
    for x in range(0, WINDOW_WIDTH, blockSize):
        for y in range(0, WINDOW_HEIGHT, blockSize):
            rect = pygame.Rect(x, y, blockSize, blockSize)
            pygame.draw.rect(SCREEN, WHITE, rect, 1)


def draw(maze, n_rows, n_cols):
    global SCREEN
    blockSize = 20 #Set the size of the grid block
    sysfont = pygame.font.get_default_font()
    font = pygame.font.SysFont(None, 35)
    for y in range(n_rows):
        for x in range(n_cols):
            color = BLACK
            if maze[y][x].valid == False:
                color = BLACK
            elif maze[y][x].start_point == True:
                color = RED
            else:
                if maze[y][x].bonus != 0:
                    if maze[y][x].visited == False:
                        color = GREEN
                    if maze[y][x].visited == True:
                        if maze[y][x].is_path == False:
                            color = YELLOW
                        else:
                            color = BLUE
                else: 
                    if maze[y][x].visited == False:
                        if maze[y][x].is_teleport == False:
                            color = WHITE
                        else:
                            color = VIOLET
                    
                    else:
                        if maze[y][x].is_path == True:
                            if maze[y][x].is_teleport == False:
                                color = BLUE
                            else:
                                color = VIOLET
                        else:
                            if maze[y][x].is_teleport == False:
                                color = YELLOW
                            else:
                                color = YELLOW
            
            rect = pygame.Rect(x*blockSize, y*blockSize, blockSize, blockSize)
            SCREEN.fill(color, rect) 



